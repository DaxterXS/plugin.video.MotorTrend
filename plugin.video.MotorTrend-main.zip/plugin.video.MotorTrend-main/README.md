# Diretta MotorTrend Kodi plugin

Kodi unofficial plugin to stream Motortrend from the official website.

## Installation

Download the contents of the repository as a zip file and then from the add-ons menu select "Install from zip file"
